<?php
$nome1 = "reidner";
$nome2 = "rodrigues";

echo "seja muito bem vindo: ".$nome1." ".$nome2;