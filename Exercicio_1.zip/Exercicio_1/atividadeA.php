<?php
echo "<h3> samando valores com php </h3>";
$num1 = 20;
$num2 = 30;

echo "primeiro numero: ".$num1;
echo "<br> segundo numero: ".$num2;
echo "<br>soma dos numeros: ".($num1+$num2);
echo "<br>multiplicacao dos numeros: ".($num1*$num2);
echo "<br>divisao dos numeros: ".($num1/$num2);
echo "<br>subtracao dos numeros: ".($num1-$num2);

?>