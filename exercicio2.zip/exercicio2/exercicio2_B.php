<?php
header("Content-type:text/html;charset=utf8");
//variaveis
$preço = 500.00;
$desconto = 15;
//calculo
$desconto2 = ($desconto/100);
$desconto3 = ($preço*$desconto2);
$total = ($preço-$desconto3);
//resultado
echo "";
echo "<br>preco ".$preço;
echo "<br>descontado ". $desconto3;
echo "<br>toral". $total;
echo "<img src='/promocao.png'>";