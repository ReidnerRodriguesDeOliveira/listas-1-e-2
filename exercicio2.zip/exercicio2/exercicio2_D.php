<?php
header("Content-type:text/html;charset=utf8");
//variaveis
$lado = 40;


//calculo
$perimetro = ($lado*4);



//resultado
echo "o perimetro do quadrado é: ".$perimetro;
echo "<img src='/quadrado.png'>";