<?php
header("Content-type:text/html;charset=utf8");
//variaveis 
$base = 10;
$altura = 20;


//calculos
$base_altura = ($base*$altura);
$area = ($base_altura/2);


//resultado
echo "a base do triangulo é ".$base;
echo "<br>a altura do trionagulo é ".$altura;
echo "<br><strong>a area do triangulo é</strong> <label style='font-size:50px; color:tomato'>".number_format($area)."</label>";
echo "<img src='/triangulo.png'>";