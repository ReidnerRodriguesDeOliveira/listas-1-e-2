<?php
header("Content-type:text/html;charset=utf8");
//variaveis 
$metros = 2;
//calculo
$cent = ($metros*100);
//resultado
echo "são 2m que transformados formam ".$cent."cm";
echo "<img src='/distancia.png'>";