<?php
header("Content-type:text/html;charset=utf8");
//entrada
echo "<h3>Peso masculino e feminino</h3>";
echo "<br><img src='/peso.png'>";
//variaveis
$altura = 1.60;
//calculo
$pesoidealM = 72.7 + $altura - 58;
$pesoidealF = 62.1 + $altura - 44.7;
//fim
echo"<br>Peso ideal para homem com ". $altura. "m seria ".$pesoidealM;
echo"<br>Peso ideal para mulher com ". $altura. "m seria ".$pesoidealF;
echo "<img src='/pesoideal.png'>";