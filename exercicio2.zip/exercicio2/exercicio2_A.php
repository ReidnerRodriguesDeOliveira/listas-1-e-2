<?php
header("Content-type:text/html;charset=utf8");
//variaveis
$peso = 80;
$altura = 1.80;
$resposta = "";
//calculo
$altuta_cm = ($altura*100);
$altura2 = ($altura*$altura);
$imc = $peso/$altura2;
//if/else
if($imc <= 18.5){
	$resposta = "Abaixo do Peso";
}else if($imc >18.5 && $imc <= 24.9){
	$resposta = "peso ideal";
}else if($imc >24.9 && $imc <= 29.9){
	$resposta = "levemente acima do Peso";
}else if($imc >29.9 && $imc <= 34.9){
	$resposta = "obesidade grau I";
}else if($imc >34.9 && $imc <= 39.9){
	$resposta = "obesidade grau II(severa)";
}else{
	$resposta = "obesidade grau III(morbida)";
}



//resultado
echo "<strong>seu imc e</strong> <label style='font-size:50px;color:#7CFC00'>".number_format($imc,2)."</label>";
echo "<img src='/imc.png'>";
//number_format é usado para definir quantas casas do numero apareceram 
echo "<br><strong>Classificação: </strong>".$resposta;