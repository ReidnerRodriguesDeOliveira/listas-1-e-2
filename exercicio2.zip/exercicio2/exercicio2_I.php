<?php
header("Content-type:text/html;charset=utf8");
//variaveis 
$conta = 500;
$pessoas = 7; 
//calculo
$total = ($conta/$pessoas);
//resultado
echo "o total a ser pago por cada um é ".number_format($total,2)."R$";
echo "<img src='/conta.jpg'>";