<?php
header("Content-type:text/html;charset=utf8");
//variaveis 
$pi = 3.14;
$diametro = 10;
//calculos
$raio = ($diametro/2);
$raio² = ($raio*$raio);
$area  = ($pi*$raio²);
//resultado
echo " a area do circulo é ". $area;
echo "<img src='/circulo.png'>";