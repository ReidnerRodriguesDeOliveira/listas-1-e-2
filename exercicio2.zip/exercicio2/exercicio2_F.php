<?php
header("Content-type:text/html;charset=utf8");
//variaveis
$quilometros = 100;
//calculos
$metros = ($quilometros*1000);
//resultado
echo " são 100KM quilometros que são convertidos para <strong> <label style='font-size:30px;color:#000066'>".$metros."m</strong></label>";
echo "<img src='/distancia.png'>";