<?php
header("Content-type:text/html;charset=utf8");
$lado = 16;
$area = ($lado*$lado);
echo "a area do quadrado e ".$area;
echo "<img src='/quadrado.png'>";